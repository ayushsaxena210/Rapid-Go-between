from django.shortcuts import render
from django.core.paginator import Paginator
#from django.contrib.auth.decorators import login_required
from MerchantAPP.models import MerchantRecords, Category
from CustomerAPP.models import CustumerRecords
from .models import Mproduct, Morder, Morderitem, Mstore
from django.contrib import messages
from datetime import datetime
from ProductAPP.models import Product
def localmerchant(request):
    cust = CustumerRecords.objects.get(user=request.user)
    obj = MerchantRecords.objects.filter(city=cust.city)
    return render(request, 'LocalMerchants.html', context={'obj': obj, 'crecord': cust})

def merchantstore(request, pk, pc=None,productid=None):
    mer = MerchantRecords.objects.get(pk=pk)
    cat = Category.objects.filter(merchantrecords__user=mer.user)
    mst = Mstore.objects.get(merchant=mer)
    cart=None
    if pc:
        products = Mproduct.objects.filter(product__category__pk=pc, seller=mer)
    else:
        products = Mproduct.objects.filter(seller=mer)
    if productid:
        prod = Mproduct.objects.filter(pk=productid, seller=mer).first()
        try:
            cart = Morder.objects.get(customer=request.user, merchant=mer, cart=True)
        except Morder.DoesNotExist:
            cart = Morder.objects.create(customer=request.user, merchant=mer)
            cart.save()
        a = Morder.objects.filter(customer=request.user, merchant=mer, morderitem__product=prod, cart=True).count()
        if a:
            messages.info(request, 'You already have this product in your cart')
        else:
            morder_obj = Morderitem.objects.create(morder=cart, product=prod)
            cart.count = cart.count+1
            cart.save()
            morder_obj.save()
            messages.info(request, 'Product added in your cart')

    paginator = Paginator(products, 25)  # Show 25 contacts per page.
    page_number = request.GET.get('page')
    products = paginator.get_page(page_number)
    return render(request, 'Merchantstore.html', context={'obj': mer, 'cat':cat, 'products': products, 'cart': cart, 'mst':mst})


def mcart(request, cartpk=0, dltpk=None):
    list = None
    cart = None
    products = None
    mstore = None
    tt, gt = 0, 0
    cus = CustumerRecords.objects.get(user=request.user)
    if cartpk:
        cart = Morder.objects.filter(pk=cartpk).first()
        mstore = Mstore.objects.filter(merchant=cart.merchant).first()
        products = Morderitem.objects.filter(morder=cart)
        tt = sum([item.qty * item.product.dic_price for item in products.all()])
    try:
        list = Morder.objects.filter(customer=request.user, cart=True).exclude(count=0)
    except Morder.DoesNotExist:
        list = None

    if request.method == 'POST' and request.user.is_authenticated:
        pkey = request.POST.get('quantity')
        qty = int(request.POST.get(pkey))
        t = request.POST.get('submit')
        products_ = Morderitem.objects.filter(pk=pkey).first()
        if t=='+':
            products_.qty = products_.qty + 1
            products_.save()
        elif products_.qty==1:
            cart.count = cart.count - 1
            cart.save()
            products_.delete()
        else:
            if t=='-' and products_.qty>1:
                products_.qty = products_.qty - 1
                products_.save()
    if dltpk:
        try:
            cart.count = cart.count - 1
            cart.save()
            abc = Morderitem.objects.filter(pk=dltpk).first()
            if abc:
                abc.delete()
        except Morderitem.DoesNotExist:
            pass
    if products:
        tt = sum([item.qty * item.product.dic_price for item in products.all()])
        gt = tt + mstore.delivery_cost
    print(list)
    return render(request, 'mcart.html', context={'list': list, 'cart': cart,
                                                  'products': products, 'cus': cus, 'mstore': mstore, 't': tt,
                                                  'gt': gt})
def checkout(request,cartpk):
    cart = Morder.objects.filter(pk=cartpk).first()
    items= Morderitem.objects.filter(morder__pk=cartpk)
    cart.cart = False
    cart.order = True
    cart.date_added = datetime.now()
    cart.save()
    return render(request, 'checkout.html', context={'cart': cart, 'items': items})


def Productmanager(request, page=1):
    mer = MerchantRecords.objects.get(user=request.user)
    cat = list(mer.productcategory.all())
    products = Product.objects.all()
    print(cat)
    return render(request, 'Productmanager.html', context={'page': page, 'cat': cat, 'products': products})