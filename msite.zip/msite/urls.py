from django.urls import path
app_name="msite"
from .views import *

urlpatterns = [
    path('', localmerchant, name="localmerchant"),
    path('store/<int:pk>/', merchantstore),
    path('store/<int:pk>/<int:pc>/', merchantstore),
    path('store/<int:pk>/<int:pc>/<int:productid>/', merchantstore),
    path('mcart/', mcart),
    path('mcart/<int:cartpk>/', mcart),
    path('mcart/<int:cartpk>/<int:dltpk>/', mcart),
    path('checkout/<int:cartpk>', checkout),
    path('Productmanager/', Productmanager),
    path('Productmanager/<int:page>', Productmanager),
]
