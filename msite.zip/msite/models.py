from django.db import models
from django.contrib.auth.models import User
from datetime import datetime
from MerchantAPP.models import MerchantRecords
from ProductAPP.models import Product

class Mproduct(models.Model):
    product = models.ForeignKey(Product, on_delete=models.SET_NULL, null=True)
    mrp_price = models.IntegerField(null=True, blank=True)
    dic_price = models.IntegerField(null=True, blank=True)
    description = models.TextField(null=True, blank=True)
    seller = models.ForeignKey(MerchantRecords, on_delete=models.CASCADE)
    def save(self, *args, **kwargs):
        super(Mproduct, self).save(*args, **kwargs)
    def __str__(self):
        return str(self.pk)

class Morder(models.Model):
    OrderID = models.AutoField(primary_key=True)
    merchant = models.ForeignKey(MerchantRecords, on_delete=models.CASCADE, null=True)
    customer = models.ForeignKey(User, on_delete=models.CASCADE)
    cart = models.BooleanField(default=True)
    order = models.BooleanField(default=False)
    date_added = models.DateTimeField(auto_now=datetime.now())
    placed = models.BooleanField(default=False)
    count = models.IntegerField(default=0, blank=True, null=True)
    def __str__(self):
        return str(self.pk)+'-'+str(self.date_added)
    def save(self, *args, **kwargs):
        super(Morder, self).save(*args, **kwargs)

class Morderitem(models.Model):
    Product_OrderID = models.AutoField(primary_key=True)
    morder = models.ForeignKey(Morder, on_delete=models.CASCADE, null=True)
    product = models.ForeignKey(Mproduct, on_delete=models.SET_NULL, null=True)
    is_ordered = models.BooleanField(default=True)
    qty = models.IntegerField(default=1)

    def __str__(self):
        return str(self.pk)
    def save(self, *args, **kwargs):
        super(Morderitem, self).save(*args, **kwargs)

class Mstore(models.Model):
    visiter_count = models.BigIntegerField(default=0)
    total_sale = models.BigIntegerField(default=0)
    merchant = models.ForeignKey(MerchantRecords, on_delete=models.SET_NULL, null=True)
    register_for_vip = models.BooleanField(default=False)
    sms = models.BooleanField(default=False)
    adds = models.BooleanField(default=False)
    website_url = models.URLField(blank=True, null=True)
    bigposter = models.ImageField(blank=True, default='msite/default.jpg', upload_to='msite', null=True)
    bigposter2 = models.ImageField(blank=True, upload_to='msite', null=True)
    smallposter = models.ImageField(blank=True, upload_to='msite', null=True)
    smallposter2 = models.ImageField(blank=True, upload_to='msite', null=True)
    #shop_rating = models.ImageField(blank=True, upload_to='msite', null=True)
    delivery_cost = models.IntegerField(default=0, blank=True, null=True)

    def __str__(self):
        return str(self.pk)

    def save(self, *args, **kwargs):
        super(Mstore, self).save(*args, **kwargs)