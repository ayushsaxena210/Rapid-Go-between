from django.apps import AppConfig


class MsiteConfig(AppConfig):
    name = 'msite'
