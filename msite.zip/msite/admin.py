from django.contrib import admin
from .models import Morderitem, Morder, Mproduct, Mstore

# Register your models here.
admin.site.register(Morderitem)
admin.site.register(Morder)
admin.site.register(Mproduct)
admin.site.register(Mstore)