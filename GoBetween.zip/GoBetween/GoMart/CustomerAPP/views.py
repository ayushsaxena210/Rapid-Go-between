from .models import CustumerRecords
from django.shortcuts import render
from django.shortcuts import render, redirect
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from .form import CustomerForm
from django.contrib.auth.models import User
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from .form import NewUserForm
from django.contrib.auth import login, authenticate, logout
from django.shortcuts import render, redirect
from django.http import HttpResponse, HttpResponseRedirect
from OrderAPP.models import Order, Merchants, OrderItem, PlaceOrder
from msite.models import Morder, Morderitem


# @login_required
# def CustomerRegistration(request):
#     if request.method == 'POST':
#         u_form = CustomerForm(request.POST, instance=request.user)
#         if u_form.is_valid():
#             u_form.save()
#             return render(request, 'CustomerRegistration.html', context)
#     else:
#         u_form = CustomerForm(instance=request.user)
#     context = {
#         'u_form': u_form,
#     }
#     return render(request, 'CustomerRegistration.html', context)
@login_required
def CustomerRegistration(request, *args, **kwargs):
    if request.method == 'POST':
        first_name = request.user.first_name
        last_name = request.user.last_name
        email = request.user.email
        mobno = request.POST.get('mobno')
        mobno2 = request.POST.get('mobno2')
        age = request.POST.get('age')
        country = request.POST.get('country')
        state = request.POST.get('state')
        city = request.POST.get('city')
        pincode = request.POST.get('pincode')
        landmark = request.POST.get('landmark')
        house_number = request.POST.get('house_number')
        longitude = request.POST.get('longitude')
        langitude = request.POST.get('langitude')
        if pincode:
            obj = CustumerRecords.objects.create(first_name=first_name, last_name=last_name, email=email, mobno=mobno,
                                                 age=age, mobno2=mobno2, country=country, state=state, city=city,
                                                 landmark=landmark, house_number=house_number, langitude=langitude,
                                                 longitude=longitude, user=request.user, pincode=pincode)
            obj.save()
            return HttpResponseRedirect('/')
    return render(request, 'CustomerRegistration.html', {})


# def clogin(request, *args, **kwargs):
#     loginname = request.POST.get('username')
#     loginpass = request.POST.get('pass')
#     data = {}
#     user = authenticate(username=loginname, password=loginpass)
#     if user is not None:
#         if user.is_active:
#             login(request, user)
#             messages.success(request, f"LOGGED IN SUCCESSFULLY : {loginname}")
#             #return render(request, "homepage.html", {})
#             return HttpResponseRedirect('/')
#         else:
#             messages.success(request, f"Wrong Login details : Invalid username or password")
#     return render(request, "clogin.html", data)
def clogin(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(username=username, password=password)
        if user is not None:
            login(request, user)
            messages.info(request, f"You are now logged in as {username}")
            return HttpResponseRedirect('/')
        else:
            messages.error(request, "Invalid username or password.")
    else:
        messages.error(request, "Invalid username or password.")

    return render(request=request,
                  template_name="clogin.html",
                  context={})


def register(request):
    if request.method == "POST":
        form = NewUserForm(request.POST)  # UserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            username = form.cleaned_data.get('username')
            messages.success(request, f"New account created: {username}")
            login(request, user)
            return HttpResponseRedirect('Registration/')

        else:
            for msg in form.error_messages:
                messages.error(request, f"{msg}: {form.error_messages[msg]}")

            return render(request=request,
                          template_name="signup.html",
                          context={"form": form})
    form = NewUserForm
    return render(request=request,
                  template_name="signup.html",
                  context={"form": form})


def homepage(request):
    crecord = None
    if request.user.is_authenticated:
        try:
            crecord = CustumerRecords.objects.get(user=request.user)
        except CustumerRecords.DoesNotExist:
            crecord = None
    return render(request=request,
                  template_name="cpage.html",
                  context={'crecord': crecord})


def clogout(request, *args, **kwargs):
    logout(request)
    messages.info(request, f"LOGGED OUT SUCCESSFULLY")
    return HttpResponseRedirect('/')


@login_required
def your_order(request, pk=0, mpk=0, cpk=0):
    records = []
    mer_obj = None
    detail_ml = {}
    order_obj = Order.objects.filter(customer=request.user)
    local_order_obj = Morder.objects.filter(customer=request.user, order=True)
    for loo in local_order_obj:
        item_obj_l = Morderitem.objects.filter(morder__pk=loo.pk)
        detail_ml[loo] = item_obj_l
    for orders in order_obj:
        obj = orders.orderitem_set.all()
        records.append(obj)
    if mpk:
        mer_obj2 = Merchants.objects.filter(pk=mpk).first()
        oder = OrderItem.objects.filter(pk=pk).first()
        oder.is_ordered = True
        oder.save()
        placed_obj = PlaceOrder.objects.create(merchant=mer_obj2,
                                               customer=CustumerRecords.objects.filter(user=request.user).first(),
                                               order=oder)
        messages.success(request, f" {oder.product} Order Placed by Shop {mer_obj2.merchant.shop_name}:")
        placed_obj.save()
    elif pk:
        mer_obj = Merchants.objects.filter(orderitem__pk=pk)
    return render(request=request,
                  template_name="yourorder.html",
                  context={'records': records, 'main': mer_obj, 'pk': pk, 'detail_ml': detail_ml, 'cpk': cpk})


def local_item_display(request, c):
    return your_order(request, cpk=c)
