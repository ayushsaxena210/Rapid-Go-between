from django.db import models
from django.contrib.auth.models import User
from datetime import datetime

class Message(models.Model):
    user = models.ForeignKey(User, on_delete=models.SET_DEFAULT, default=None)
    subject = models.CharField(max_length=60)
    text = models.TextField()
    at_date_time = models.DateTimeField(default=datetime.now())
    ##add 1 more field for color {to distinguse message acorg}
class CustumerRecords(models.Model):
    customerID = models.AutoField(primary_key=True)
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    first_name = models.CharField(max_length=30)
    last_name = models.CharField(max_length=30)
    mobno = models.BigIntegerField()
    mobno2 = models.BigIntegerField(default=None, null=True, blank=True)
    age = models.IntegerField()
    email = models.EmailField()
    country = models.CharField(max_length=30)
    state = models.CharField(max_length=30)
    city = models.CharField(max_length=30)
    pincode = models.IntegerField()
    landmark = models.CharField(max_length=30)
    house_number = models.CharField(max_length=40)
    longitude = models.FloatField()
    langitude = models.FloatField()
    accounttype = models.CharField(max_length=1, default='C')
    messages = models.ManyToManyField(Message, blank=True)
    def save(self, *args, **kwargs):
        super(CustumerRecords, self).save(*args, **kwargs)
    def __str__(self):
        return str(self.customerID)+self.first_name+self.last_name