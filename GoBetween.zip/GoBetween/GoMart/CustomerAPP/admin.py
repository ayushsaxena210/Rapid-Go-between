from django.contrib import admin
from .models import CustumerRecords, Message

# Register your models here.
admin.site.register(CustumerRecords)
admin.site.register(Message)