from django.urls import path
from . import views
app_name="CustomerAPP"
urlpatterns = [
    path('', views.homepage,name="chome"),
    path('Registration/', views.CustomerRegistration, name="Registration"),
    path('login/', views.clogin, name="Login"),
    path('signup', views.register, name="Signup"),
    path('logout/', views.clogout, name="Logout"),
    path('yourorder/', views.your_order, name="your_order"),
    path('yourorder/<int:pk>/', views.your_order, name="your_order"),
    path('yourorder/<int:pk>/<int:mpk>/', views.your_order, name="your_order"),
    path('yourorder2/<int:c>/', views.local_item_display, name="local_item_display"),
]
