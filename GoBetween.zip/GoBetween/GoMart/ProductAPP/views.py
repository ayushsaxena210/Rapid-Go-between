from django.shortcuts import render
from .form import ProductForm
from django.contrib.auth.decorators import login_required
from .models import Product
from django.core.paginator import Paginator
from CustomerAPP.models import CustumerRecords
from OrderAPP.models import OrderItem, Cart
from django.contrib import messages

@login_required
def addproduct(request):
    if request.method == 'POST':
        u_form = ProductForm(request.POST, instance=request.user)
        if u_form.is_valid():
            u_form.save()
            return render(request, 'addproduct.html', {})
    else:
        u_form = ProductForm(instance=request.user)
    context = {
        'u_form': u_form,
    }
    return render(request, 'addproduct.html', context)

def show_product(request):
    return render(request, 'product.html', context={'obj': Product.objects.all})


def listing1(request):
    if request.method == 'POST' and request.user.is_authenticated:
        itemno = request.POST.get('item')
        product = Product.objects.filter(ProductID=itemno).first()
        try:
            obj_Cart = Cart.objects.get(owner=request.user)
        except Cart.DoesNotExist:
            obj_Cart = Cart.objects.create(owner=request.user)
            obj_Cart.save()
        a = Cart.objects.filter(owner=request.user, orderitem__product=product).count()
        if a:
            messages.info(request, 'You already have this product in your cart')
        else:
            Order_obj=OrderItem.objects.create(cart=obj_Cart, product=product)
            Order_obj.save()
            messages.info(request, 'product added in your cart')
    crecord = None
    if request.user.is_authenticated:
        try:
            crecord = CustumerRecords.objects.get(user=request.user)
        except CustumerRecords.DoesNotExist:
            crecord = None
    Product_list = Product.objects.filter(category__name='vegetable')
    paginator = Paginator(Product_list, 30) # Show 25 contacts per page.

    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)
    return render(request, 'category.html', {'page_obj': page_obj,
                                             'crecord': crecord})


def listing2(request):
    if request.method == 'POST' and request.user.is_authenticated:
        itemno = request.POST.get('item')
        product = Product.objects.filter(ProductID=itemno).first()
        try:
            obj_Cart = Cart.objects.get(owner=request.user)
        except Cart.DoesNotExist:
            obj_Cart = Cart.objects.create(owner=request.user)
            obj_Cart.save()
        a = Cart.objects.filter(owner=request.user, orderitem__product=product).count()
        if a:
            messages.info(request, 'You already have this product in your cart')
        else:
            Order_obj=OrderItem.objects.create(cart=obj_Cart, product=product)
            Order_obj.save()
            messages.info(request, 'product added in your cart')
    crecord = None
    if request.user.is_authenticated:
        try:
            crecord = CustumerRecords.objects.get(user=request.user)
        except CustumerRecords.DoesNotExist:
            crecord = None
    Product_list = Product.objects.filter(category__name='grocery')
    paginator = Paginator(Product_list, 30) # Show 25 contacts per page.

    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)
    return render(request, 'category.html', {'page_obj': page_obj,
                                             'crecord': crecord})


def listing3(request):
    if request.method == 'POST' and request.user.is_authenticated:
        itemno = request.POST.get('item')
        product = Product.objects.filter(ProductID=itemno).first()
        try:
            obj_Cart = Cart.objects.get(owner=request.user)
        except Cart.DoesNotExist:
            obj_Cart = Cart.objects.create(owner=request.user)
            obj_Cart.save()
        a = Cart.objects.filter(owner=request.user, orderitem__product=product).count()
        if a:
            messages.info(request, 'You already have this product in your cart')
        else:
            Order_obj=OrderItem.objects.create(cart=obj_Cart, product=product)
            Order_obj.save()
            messages.info(request, 'product added in your cart')
    crecord = None
    if request.user.is_authenticated:
        try:
            crecord = CustumerRecords.objects.get(user=request.user)
        except CustumerRecords.DoesNotExist:
            crecord = None
    Product_list = Product.objects.filter(category__name='fruits')
    paginator = Paginator(Product_list, 30) # Show 25 contacts per page.

    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)
    return render(request, 'category.html', {'page_obj': page_obj,
                                             'crecord': crecord})



def listing4(request):
    if request.method == 'POST' and request.user.is_authenticated:
        itemno = request.POST.get('item')
        product = Product.objects.filter(ProductID=itemno).first()
        try:
            obj_Cart = Cart.objects.get(owner=request.user)
        except Cart.DoesNotExist:
            obj_Cart = Cart.objects.create(owner=request.user)
            obj_Cart.save()
        a = Cart.objects.filter(owner=request.user, orderitem__product=product).count()
        if a:
            messages.info(request, 'You already have this product in your cart')
        else:
            Order_obj=OrderItem.objects.create(cart=obj_Cart, product=product)
            Order_obj.save()
            messages.info(request, 'product added in your cart')
    crecord = None
    if request.user.is_authenticated:
        try:
            crecord = CustumerRecords.objects.get(user=request.user)
        except CustumerRecords.DoesNotExist:
            crecord = None
    Product_list = Product.objects.filter(category__name='medicines')
    paginator = Paginator(Product_list, 30) # Show 25 contacts per page.

    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)
    return render(request, 'category.html', {'page_obj': page_obj,
                                             'crecord': crecord})


def listing(request):
    if request.method == 'POST' and request.user.is_authenticated:
        itemno = request.POST.get('item')
        product = Product.objects.filter(ProductID=itemno).first()
        try:
            obj_Cart = Cart.objects.get(owner=request.user)
        except Cart.DoesNotExist:
            obj_Cart = Cart.objects.create(owner=request.user)
            obj_Cart.save()
        a = Cart.objects.filter(owner=request.user, orderitem__product=product).count()
        if a:
            messages.info(request, 'You already have this product in your cart')
        else:
            Order_obj=OrderItem.objects.create(cart=obj_Cart, product=product)
            Order_obj.save()
            messages.info(request, 'product added in your cart')
        # product_obj = OrderItem.objects.get_or_create(product=product)#1
        # print(product_obj[0].product.Productname)
        # if product_obj[0] in obj_Cart[0].items.all():
        #     messages.info(request, 'You already have this product in your cart')
        # else:
        #     messages.info(request, 'product added in your cart')
        #     obj_Cart[0].items.add(product_obj[0])
        #     obj_Cart[0].save()
    crecord = None
    if request.user.is_authenticated:
        try:
            crecord = CustumerRecords.objects.get(user=request.user)
        except CustumerRecords.DoesNotExist:
            crecord = None
    Product_list = Product.objects.all()
    paginator = Paginator(Product_list, 30) # Show 25 contacts per page.

    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)
    return render(request, 'category.html', {'page_obj': page_obj,
                                             'crecord': crecord})































# def addproduct():
#     Productname =
#     category =
#     rating =
#     mrp_price =
#     dic_price =
#     qty =
#     weight =
#     Vegetarian =
#     Brand =
#     image =