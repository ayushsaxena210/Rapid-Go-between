from .models import Product
from django import forms


class ProductForm(forms.ModelForm):
    class Meta:
        model = Product
        fields = ['Productname',
                  'category',
                  'rating',
                  'mrp_price',
                  'dic_price',
                  'qty',
                  'weight',
                  'Vegetarian',
                  'Brand',
                  'image']
