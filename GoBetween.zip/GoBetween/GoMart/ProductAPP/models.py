from django.db import models
from datetime import datetime
from PIL import Image
from MerchantAPP.models import Category

class Product(models.Model):
    ProductID = models.AutoField(primary_key=True)
    Productname = models.CharField(max_length=30)
    category = models.ForeignKey(Category, default=None, on_delete=models.SET_DEFAULT)
    rating = models.IntegerField(null=True, blank=True)
    mrp_price = models.IntegerField(null=True, blank=True)
    dic_price = models.IntegerField(default=0, null=True, blank=True)
    qty = models.CharField(max_length=30, null=True, blank=True, default=1)
    weight = models.CharField(max_length=30, null=True, blank=True)
    Vegetarian = models.BooleanField(default=True)
    Brand = models.CharField(max_length=30)
    at_date_time = models.DateTimeField(default=datetime.now())
    image = models.ImageField(default='default.png', upload_to='products')
    image2 = models.ImageField(blank=True, upload_to='products', null=True)
    image3 = models.ImageField(blank=True, upload_to='products', null=True)
    image4 = models.ImageField(blank=True, upload_to='products', null=True)
    def __str__(self):
        return self.Productname
    def save(self, *args, **kwargs):
        super(Product, self).save(*args, **kwargs)
        img = Image.open(self.image.path)
        if img.height > 350 or img.width > 350:
            output_size = (350, 350)
            img.thumbnail(output_size)
            img.save(self.image.path)