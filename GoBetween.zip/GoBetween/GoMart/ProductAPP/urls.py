from django.urls import path
from . import views
app_name="ProductAPP"


urlpatterns = [
    path('', views.show_product,name="Addproduct"),
    path('addproduct/', views.addproduct,name="Addproduct"),
    path('category/', views.listing, name="listing"),
    path('category1/', views.listing1, name="listing1"),
    path('category2/', views.listing2, name="listing2"),
    path('category3/', views.listing3, name="listing3"),
    path('category4/', views.listing4, name="listing4"),
]
