from django.apps import AppConfig


class OrderappConfig(AppConfig):
    name = 'OrderAPP'
