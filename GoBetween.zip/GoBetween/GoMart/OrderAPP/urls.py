from django.urls import path
from . import views
app_name="OrderAPP"
urlpatterns = [
    path('', views.cart, name="cart"),
    path('placedorder/', views.placed_order, name="placed_order"),
]
