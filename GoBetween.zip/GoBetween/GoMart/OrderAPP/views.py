from django.shortcuts import render
from .models import Cart, OrderItem, Order
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from django.http import HttpResponse, HttpResponseRedirect
from CustomerAPP.models import CustumerRecords


@login_required
def cart(request):
    crecord = None
    if request.user.is_authenticated:
        try:
            crecord = CustumerRecords.objects.get(user=request.user)
            citems = Cart.objects.filter(owner=request.user).first()
            citems = citems.orderitem_set.all()
            total_price = sum([c.qty * c.product.dic_price for c in citems.all()])

        except CustumerRecords.DoesNotExist:
            crecord = None
            citems = None
    if request.method == 'POST' and request.user.is_authenticated:
        pname = request.POST.get('quantity')
        qty = int(request.POST.get(pname))
        t = request.POST.get('submit_button')
        if t == '-' and qty > 0:
            try:
                item = citems.get(pk=pname)
                item.qty = item.qty - 1
                item.save()
                qty -= 1
                total_price = sum([c.qty * c.product.dic_price for c in citems.all()])
            except OrderItem.DoesNotExist:
                pass

        if t == '+' and qty > 0:
            try:
                item = citems.get(pk=pname)
                item.qty = item.qty + 1
                item.save()
                total_price = sum([c.qty * c.product.dic_price for c in citems.all()])
                qty += 1
            except OrderItem.DoesNotExist:
                pass
        if qty == 0:
            citems.filter(pk=pname).delete()
            total_price = sum([c.qty * c.product.dic_price for c in citems.all()])
    if request.method == 'GET' and request.user.is_authenticated:
        k = request.GET.get('check')
        if k == 'Reset':
            citems.all().delete()

    return render(request=request,
                  template_name="cart.html",
                  context={'crecord': crecord, 'citems': citems, 'total_price': total_price})


@login_required
def placed_order(request):
    if request.method == 'POST' and request.user.is_authenticated:
        check = request.POST.get('check')
        if check == 'place':
            try:
                obj_Order = Order.objects.get(customer=request.user)
            except Order.DoesNotExist:
                obj_Order = Order.objects.create(customer=request.user)
                obj_Order.save()
            cart_record = Cart.objects.filter(owner=request.user).first()
            orderitems = cart_record.orderitem_set.all()
            for orderitem in orderitems:
                orderitem.cart = None
                orderitem.order = obj_Order
                orderitem.is_ordered = False
                orderitem.save()
            messages.info(request, 'your order is shared with local merchants')
    try:
        crecord = CustumerRecords.objects.get(user=request.user)
        citems = Cart.objects.filter(owner=request.user).first()
        citems = citems.orderitem_set.all()
        total_price = sum([c.qty * c.product.dic_price for c in citems.all()])
    except CustumerRecords.DoesNotExist:
        crecord = None
        citems = None
    return render(request=request,
                  template_name="order_placed.html",
                  context={'crecord': crecord, 'citems': citems, 'total_price': total_price})

