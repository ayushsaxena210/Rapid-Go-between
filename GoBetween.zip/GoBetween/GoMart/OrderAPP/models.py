from django.db import models
from django.contrib.auth.models import User
from datetime import datetime
from MerchantAPP.models import MerchantRecords
from ProductAPP.models import Product
from CustomerAPP.models import CustumerRecords

class Cart(models.Model):
    owner = models.ForeignKey(User, on_delete=models.SET_NULL, null=True)
    is_ordered = models.BooleanField(default=False)
    def save(self, *args, **kwargs):
        super(Cart, self).save(*args, **kwargs)

class Merchants(models.Model):
    merchant = models.ForeignKey(MerchantRecords, default=None, on_delete=models.SET_DEFAULT)
    sellingprice = models.IntegerField()
    m_expected_dilivery_date_time = models.TimeField()
    deliver_price = models.IntegerField(default=None)
    def save(self, *args, **kwargs):
        super(Merchants, self).save(*args, **kwargs)
    def __str__(self):
        return str(self.pk)+' '+self.merchant.first_name+' '+str(self.merchant.MerchantID)

class Order(models.Model):
    OrderID = models.AutoField(primary_key=True)
    customer = models.ForeignKey(User, on_delete=models.CASCADE)
    orderDateTime = models.DateTimeField(default=datetime.now())
    #expected_dilivery_date_time = models.DateTimeField(default='no data', blank=True) #{not using now}
    #ordertype = models.BooleanField(default=True)  #{not using now}              #self pickup order false ,for dilivery order true

    def save(self, *args, **kwargs):
        super(Order, self).save(*args, **kwargs)
    def __str__(self):
        return str(self.OrderID)+self.customer.first_name


class OrderItem(models.Model):
    cart = models.ForeignKey(Cart, on_delete=models.CASCADE, null=True, blank=True)
    order = models.ForeignKey(Order, on_delete=models.CASCADE, null=True, blank=True)
    product = models.ForeignKey(Product, on_delete=models.SET_NULL, null=True)
    is_ordered = models.BooleanField(default=True)
    date_added = models.DateTimeField(auto_now=datetime.now())
    qty = models.IntegerField(default=1)
    merchants_accepted = models.ManyToManyField(Merchants, default='no users', blank=True)
    def __str__(self):
        return str(self.pk)+'-'+self.product.Productname+'-'+str(self.qty)+'-'+str(self.date_added)
    def save(self, *args, **kwargs):
        super(OrderItem, self).save(*args, **kwargs)

class PlaceOrder(models.Model):
    placed_OrderID = models.AutoField(primary_key=True)
    order = models.ForeignKey(OrderItem, default=None, on_delete=models.SET_DEFAULT, null=True)
    customer = models.ForeignKey(CustumerRecords, on_delete=models.CASCADE)
    merchant = models.ForeignKey(Merchants, on_delete=models.CASCADE)
    def save(self, *args, **kwargs):
        super(PlaceOrder, self).save(*args, **kwargs)
    def __str__(self):
        return str(self.placed_OrderID)
