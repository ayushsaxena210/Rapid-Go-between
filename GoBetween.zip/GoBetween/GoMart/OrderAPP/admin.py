from .models import Merchants, Order, PlaceOrder, OrderItem, Cart
from django.contrib import admin
# Register your models here.
admin.site.register(Merchants)
admin.site.register(Order)
admin.site.register(PlaceOrder)
admin.site.register(OrderItem)
admin.site.register(Cart)
