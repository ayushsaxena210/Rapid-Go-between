from django.shortcuts import render
from django.contrib import messages
from django import forms
from django.contrib.auth import authenticate
from CustomerAPP.models import CustumerRecords, Message
from MerchantAPP.models import MerchantRecords, Category
from msite.models import Mstore, Mproduct
from django.contrib.auth.models import User
from django.core.paginator import Paginator
#########
from ProductAPP.models import Product
from MerchantAPP.models import Category
##########
class ImageUploadForm(forms.Form):
    bigposter = forms.ImageField()
class ImageUploadForm2(forms.Form):
    smallposter = forms.ImageField()
class ImageUploadForm3(forms.Form):
    smallposter2 = forms.ImageField()

def homepage(request):
    crecord = None
    Mrecord = None
    if request.user.is_authenticated:
        try:
            crecord = CustumerRecords.objects.get(user=request.user)
        except CustumerRecords.DoesNotExist:
            crecord = None

        try:
            Mrecord = MerchantRecords.objects.get(user=request.user)
        except MerchantRecords.DoesNotExist:
            Mrecord = None
    return render(request=request,
                  template_name="homepage.html",
                  context={'crecord': crecord, 'Mrecord': Mrecord})

def terms_conditions(request):
    crecord = None
    Mrecord = None
    if request.user.is_authenticated:
        try:
            crecord = CustumerRecords.objects.get(user=request.user)
        except CustumerRecords.DoesNotExist:
            crecord = None

        try:
            Mrecord = MerchantRecords.objects.get(user=request.user)
        except MerchantRecords.DoesNotExist:
            Mrecord = None
    return render(request=request,
                  template_name="t&c.html",
                  context={'crecord': crecord, 'Mrecord': Mrecord})



def f_and_q(request):
    crecord = None
    Mrecord = None
    if request.user.is_authenticated:
        try:
            crecord = CustumerRecords.objects.get(user=request.user)
        except CustumerRecords.DoesNotExist:
            crecord = None

        try:
            Mrecord = MerchantRecords.objects.get(user=request.user)
        except MerchantRecords.DoesNotExist:
            Mrecord = None
    return render(request=request,
                  template_name="f&q.html",
                  context={'crecord': crecord, 'Mrecord': Mrecord})


def l_and_a(request):
    crecord = None
    Mrecord = None
    if request.user.is_authenticated:
        try:
            crecord = CustumerRecords.objects.get(user=request.user)
        except CustumerRecords.DoesNotExist:
            crecord = None

        try:
            Mrecord = MerchantRecords.objects.get(user=request.user)
        except MerchantRecords.DoesNotExist:
            Mrecord = None
    # #################################################3
    # from glob import glob
    # obj_category = Category.objects.get(name='grocery')
    # pth = "C:/My Web Sites/gomart/www.bigbasket.com_443/media/uploads/p/s/"
    # a = glob(pth + "*.jpg")
    # temp = []
    # for aardd in a:
    #     temp.append(aardd.split('\\'))
    # itemarr = []
    # for item in temp:
    #     itemarr.append(item[1].split('-'))
    #
    # main2 = []
    # main = []
    # ruf = []
    # for i in range(len(a)):
    #     img ='s/'+ a[i].split('\\')[1]
    #     if itemarr[i][1] == 'fresho':
    #         itemarr[i][1] = 'fresh'
    #     if itemarr[i][1] != 'fresh':
    #         pname = itemarr[i][-1].split('.')[0]
    #         pname = " ".join(itemarr[i][2:-1:]) + ' ' + str(pname)
    #
    #         id_ = itemarr[i][0].split('_')[0]
    #         if itemarr[i][1] != 'bb':
    #             if (len(itemarr[i][1]) < 3):
    #                 brand = " ".join(itemarr[i][1:3])
    #             else:
    #                 brand = itemarr[i][1]
    #             if id_ not in ruf:
    #                 ruf.append(id_)
    #                 main.append([img, pname, brand])
    #                 print(img)
    #                 obj_product_add = Product.objects.create(Productname=pname, category=obj_category, Brand=brand, image=img)
    #                 obj_product_add.save()
    #             else:
    #                 main2.append([img, pname, brand])
    #
    # #######################
    return render(request=request,
                  template_name="legal&about.html",
                  context={'crecord': crecord, 'Mrecord': Mrecord})

def messages(request):
    crecord = None
    Mrecord = None
    if request.user.is_authenticated:
        try:
            crecord = CustumerRecords.objects.get(user=request.user)
        except CustumerRecords.DoesNotExist:
            crecord = None

        try:
            Mrecord = MerchantRecords.objects.get(user=request.user)
        except MerchantRecords.DoesNotExist:
            Mrecord = None
    obj = list(Message.objects.filter(user=request.user).order_by('-at_date_time'))
    print(obj)
    paginator = Paginator(obj, 10)
    page_number = request.GET.get('page')
    obj = paginator.get_page(page_number)

    return render(request=request,
                  template_name="message.html",
                  context={'crecord': crecord, 'Mrecord': Mrecord, 'messages': obj})

def account(request, page=1):
    crecord = None
    Mrecord = None
    mstore = None
    msg = None
    products = None
    if request.user.is_authenticated:
        try:
            crecord = CustumerRecords.objects.get(user=request.user)
        except CustumerRecords.DoesNotExist:
            crecord = None
        try:
            Mrecord = MerchantRecords.objects.get(user=request.user)
            mstore = list(Mstore.objects.get_or_create(merchant=Mrecord))[0]
        except MerchantRecords.DoesNotExist:
            Mrecord = None
    if crecord:
        if request.method == 'POST' and page == 1:
             phone = request.POST.get('phone')
             phone2 = request.POST.get('phone2')
             if phone != crecord.mobno or phone2 != crecord.mobno2:
                 crecord.mobno = phone
                 crecord.mobno2 = phone2
                 crecord.save()
        if request.method == 'POST' and page == 2:
             state = request.POST.get('state')
             city = request.POST.get('city')
             landmark = request.POST.get('landmark')
             address = request.POST.get('address')
             if state != crecord.state or city != crecord.city or landmark != crecord.landmark or address != crecord.house_number:
                 crecord.state = state
                 crecord.city = city
                 crecord.landmark = landmark
                 crecord.house_number = address
                 crecord.save()
        if request.method == 'POST' and page == 3:
             cpass = request.POST.get('pass')
             newpass = request.POST.get('newpass')
             newpass1 = request.POST.get('newpass1')
             if newpass1!=newpass:
                 msg=2
             else:
                 user = authenticate(username=request.user, password=cpass)
                 if user is not None:
                     user.set_password(newpass)
                     user.save()
                     msg=3
                 else:
                     msg=1
    if Mrecord:
        if request.method == 'POST' and page == 1:
            phone = request.POST.get('phone')
            phone2 = request.POST.get('phone2')
            if phone != Mrecord.mobno or phone2 != Mrecord.mobno2:
                Mrecord.mobno = phone
                Mrecord.mobno2 = phone2
                Mrecord.save()
        if request.method == 'POST' and page == 2:
            state = request.POST.get('state')
            city = request.POST.get('city')
            landmark = request.POST.get('landmark')
            address = request.POST.get('address')
            if state != Mrecord.state or city != Mrecord.city or landmark != Mrecord.landmark or address != Mrecord.house_number:
                Mrecord.state = state
                Mrecord.city = city
                Mrecord.landmark = landmark
                Mrecord.house_number = address
                Mrecord.save()
        if request.method == 'POST' and page == 3:
            cpass = request.POST.get('pass')
            newpass = request.POST.get('newpass')
            newpass1 = request.POST.get('newpass1')
            if newpass1 != newpass:
                msg = 2
            else:
                user = authenticate(username=request.user, password=cpass)
                if user is not None:
                    user.set_password(newpass)
                    user.save()
                    msg = 3
                else:
                    msg = 1
        if request.method == 'POST' and page == 4:
            fb = request.POST.get('fblink')
            ins = request.POST.get('inlink')
            tw = request.POST.get('twlink')
            url = request.POST.get('weburl')
            if Mrecord.fb_link != fb:
                Mrecord.fb_link=fb
                Mrecord.save()
            if Mrecord.in_link != ins:
                Mrecord.in_link=ins
                Mrecord.save()
            if Mrecord.twitter_link != tw:
                Mrecord.twitter_link = tw
                Mrecord.save()
            if mstore.website_url != url:
                mstore.website_url=url
                mstore.save()
        if request.method == 'POST' and page == 5:
            shopname = request.POST.get('shopname')
            gstinno = request.POST.get('gstinno')
            # = request.POST.get('drange')
            Mrecord.aboutstore = request.POST.get('AboutUs')
            Mrecord.return_exchange = request.POST.get('return&exchange')
            Mrecord.shipping_info = request.POST.get('shippinginfo')
            diliverycost = request.POST.get('diliverycost')
            grocery = request.POST.get('grocery')
            vegetable = request.POST.get('vegetable')
            fruits = request.POST.get('fruits')
            medicines = request.POST.get('medicines')

            veg = Category.objects.get(name='vegetable')
            gro = Category.objects.get(name='grocery')
            fru = Category.objects.get(name='fruits')
            med = Category.objects.get(name='medicines')
            if vegetable == '1' and veg not in Mrecord.productcategory.all():
                Mrecord.productcategory.add(veg)

            if grocery == '1' and gro not in Mrecord.productcategory.all():
                Mrecord.productcategory.add(gro)

            if fruits == '1' and fru not in Mrecord.productcategory.all():
                Mrecord.productcategory.add(fru)

            if medicines == '1' and med not in Mrecord.productcategory.all():
                Mrecord.productcategory.add(med)
            # To remove category if unchecked
            if vegetable != '1' and veg in Mrecord.productcategory.all():
                Mrecord.productcategory.remove(veg)

            if grocery != '1' and gro in Mrecord.productcategory.all():
                Mrecord.productcategory.remove(gro)

            if fruits != '1' and fru in Mrecord.productcategory.all():
                Mrecord.productcategory.remove(fru)

            if medicines != '1' and med in Mrecord.productcategory.all():
                Mrecord.productcategory.remove(med)

            if shopname != Mrecord.shop_name:
                Mrecord.shop_name = shopname

            if gstinno != Mrecord.tin_number:
                Mrecord.tin_number = gstinno

            if diliverycost != mstore.delivery_cost:
                mstore.delivery_cost = diliverycost
                mstore.save()
            Mrecord.save()
        if request.method == 'POST' and page == 6:
            form = ImageUploadForm(request.POST, request.FILES)
            if form.is_valid():
                bigposter = form.cleaned_data['bigposter']
                mstore.bigposter = bigposter
                print(bigposter)
                mstore.save()
            form = ImageUploadForm2(request.POST, request.FILES)
            if form.is_valid():
                smallposter = form.cleaned_data['smallposter']
                mstore.smallposter = smallposter
                print(smallposter)
                mstore.save()
            form = ImageUploadForm3(request.POST, request.FILES)
            if form.is_valid():
                smallposter2 = form.cleaned_data['smallposter2']
                mstore.smallposter2 = smallposter2
                print(smallposter2)
                mstore.save()
        if page == 8:
            products = Mproduct.objects.filter(seller=Mrecord)
            paginator = Paginator(products, 25)  # Show 25 contacts per page.
            page_number = request.GET.get('page')
            products = paginator.get_page(page_number)
    return render(request=request,
                  template_name="account.html",
                  context={'crecord': crecord, 'Mrecord': Mrecord, 'page': page, 'msg': msg, 'mstore': mstore, 'products': products})
