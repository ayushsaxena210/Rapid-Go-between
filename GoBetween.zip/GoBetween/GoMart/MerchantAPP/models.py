from django.db import models
from django.contrib.auth.models import User
from datetime import datetime
from CustomerAPP.models import Message


class Category(models.Model):
    name = models.CharField(max_length=30)
    def __str__(self):
        return self.name


class MerchantRecords(models.Model):
    MerchantID = models.AutoField(primary_key=True)
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    first_name = models.CharField(max_length=30)
    last_name =models.CharField(max_length=30)
    mobno = models.BigIntegerField()
    mobno2 = models.BigIntegerField(default=None, null=True, blank=True)
    age = models.IntegerField()
    email = models.EmailField()
    country = models.CharField(max_length=30)
    state = models.CharField(max_length=30)
    city = models.CharField(max_length=30)
    pincode = models.IntegerField()
    landmark = models.CharField(max_length=30)
    house_number = models.CharField(max_length=20)
    longitude = models.FloatField()
    langitude = models.FloatField()
    accounttype = models.CharField(max_length=1, default='M')
    shop_name = models.CharField(max_length=60)
    tin_number = models.CharField(max_length=30, default=None, null=True, blank=True)
    productcategory = models.ManyToManyField(Category)
    messages = models.ManyToManyField(Message, blank=True)
    abs="Hello. Welcome to Wríghtwood Furniture. So glad you're here"
    re ="We do not offer merchandise exchanges on orders"
    sp = "We're happy to offer Free Standard Shipping on orders over 500 RS!"
    aboutstore = models.TextField(default=abs)
    return_exchange = models.TextField(default=re)
    shipping_info = models.TextField(default=sp)
    fb_link = models.URLField(blank=True, null=True, default="#")
    in_link = models.URLField(blank=True, null=True, default="#")
    twitter_link = models.URLField(blank=True, null=True, default="#")
    def save(self, *args, **kwargs):
        super(MerchantRecords, self).save(*args, **kwargs)
    def __str__(self):
        return str(self.pk)+str(self.MerchantID)+self.first_name+self.last_name