from django.apps import AppConfig


class MerchantappConfig(AppConfig):
    name = 'MerchantAPP'
