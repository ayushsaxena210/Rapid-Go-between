from .models import MerchantRecords, Category
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from .form import NewUserForm
from django.contrib.auth import login, authenticate, logout
from django.shortcuts import render, redirect
from django.http import HttpResponse, HttpResponseRedirect
from CustomerAPP.models import CustumerRecords
from OrderAPP.models import Order, Merchants, OrderItem, PlaceOrder, Merchants
from django.core.paginator import Paginator
from math import radians, cos, sin, asin, sqrt
from msite.models import Morder, Morderitem
# @login_required
# def CustomerRegistration(request):
#     if request.method == 'POST':
#         u_form = CustomerForm(request.POST, instance=request.user)
#         if u_form.is_valid():
#             u_form.save()
#             return render(request, 'CustomerRegistration.html', context)
#     else:
#         u_form = CustomerForm(instance=request.user)
#     context = {
#         'u_form': u_form,
#     }
#     return render(request, 'CustomerRegistration.html', context)
@login_required
def MerchantRegistration(request, *args, **kwargs):
    if request.method == 'POST':
        first_name = request.user.first_name
        last_name = request.user.last_name
        email = request.user.email
        mobno = request.POST.get('mobno')
        mobno2 = request.POST.get('mobno2')
        age = request.POST.get('age')
        country = request.POST.get('country')
        state = request.POST.get('state')
        city = request.POST.get('city')
        pincode = request.POST.get('pincode')
        landmark = request.POST.get('landmark')
        house_number = request.POST.get('house_number')
        longitude = request.POST.get('longitude')
        langitude = request.POST.get('langitude')
        shop_name = request.POST.get('shop_name')
        tin_number = request.POST.get('tin_number')
        productcategory1 = request.POST.get('productcategory2')
        productcategory2 = request.POST.get('productcategory3')
        productcategory3 = request.POST.get('productcategory4')
        productcategory4 = request.POST.get('productcategory5')
        productcategory5 = request.POST.get('productcategory1')
        productcategory = list(set([productcategory1, productcategory2, productcategory3, productcategory4, productcategory5]))
        productcategory.remove('')

        if pincode:
            obj=MerchantRecords.objects.create(first_name=first_name, last_name=last_name, email=email, mobno=mobno,
                                               age=age, mobno2=mobno2, country=country, state=state, city=city,
                                               landmark=landmark, house_number=house_number, langitude=langitude,
                                               longitude=longitude, user=request.user,pincode=pincode, shop_name=shop_name,
                                               tin_number=tin_number)
            productcategory = [Category.objects.create(name=category) for category in productcategory if
                               category is not None]
            for data in productcategory:
                obj.productcategory.add(data)
            obj.save()
            return HttpResponseRedirect('/')
    return render(request, 'MerchantRegistration.html', {})

def mlogin(request):
    if request.method == 'POST':
        form = AuthenticationForm(request=request, data=request.POST)
        if form.is_valid():
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')
            user = authenticate(username=username, password=password)
            if user is not None:
                login(request, user)
                messages.info(request, f"You are now logged in as {username}")
                return HttpResponseRedirect('/')
            else:
                messages.error(request, "Invalid username or password.")
        else:
            messages.error(request, "Invalid username or password.")
    form = AuthenticationForm()
    return render(request = request,
                    template_name = "clogin.html",
                    context={"form":form})

def register(request):
    if request.method == "POST":
        form = NewUserForm(request.POST) #UserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            username = form.cleaned_data.get('username')
            messages.success(request, f"New account created: {username}")
            login(request, user)
            return HttpResponseRedirect('registration/')

        else:
            for msg in form.error_messages:
                messages.error(request, f"{msg}: {form.error_messages[msg]}")

            return render(request = request,
                          template_name = "signup.html",
                          context={"form":form})

    form = NewUserForm
    return render(request = request,
                  template_name = "signup.html",
                  context={"form":form})


def mpage(request):
    crecord = None
    if request.user.is_authenticated:
        try:
            crecord = CustumerRecords.objects.get(user=request.user)
        except CustumerRecords.DoesNotExist:
            crecord = None
    return render(request=request,
                  template_name="mpage.html",
                  context={'crecord': crecord})

def mlogout(request, *args, **kwargs):
    logout(request)
    messages.info(request, f"LOGGED OUT SUCCESSFULLY")
    return HttpResponseRedirect('/merchant/')

def check_range(r, lon1, lon2, lat1, lat2):
    lon1 = radians(lon1)
    lon2 = radians(lon2)
    lat1 = radians(lat1)
    lat2 = radians(lat2)
    dlon = lon2 - lon1
    dlat = lat2 - lat1
    a = sin(dlat / 2) ** 2 + cos(lat1) * cos(lat2) * sin(dlon / 2) ** 2
    c = 2 * asin(sqrt(a))
    ra = 6371
    distance = c * ra
    if distance <= r:
        return True
    return False

@login_required
def timeline(request):
    records=[]
    merch_obj = MerchantRecords.objects.filter(user=request.user).first()
    order_obj = Order.objects.filter(customer__custumerrecords__city=merch_obj.city)
    for orders in order_obj:
        obj = orders.orderitem_set.all()
        records.append(obj)
    paginator = Paginator(records, 5)  # Show 25 contacts per page.
    page_number = request.GET.get('page')
    records = paginator.get_page(page_number)
    if request.method == 'POST':
        id = request.POST.get('id')
        selling_price = request.POST.get(id)
        deliver_price = request.POST.get(id+'d')
        time = request.POST.get(id+'t')
        order_obj = OrderItem.objects.get(pk=id)
        merobj = Merchants.objects.create(merchant=merch_obj, sellingprice=selling_price, deliver_price=deliver_price, m_expected_dilivery_date_time=time)
        order_obj.merchants_accepted.add(merobj)
        order_obj.save()
        messages.info(request, "Order Accepted")
    return render(request=request,
                  template_name="maintimeline.html",
                  context={'order_obj': order_obj, 'records': records})


@login_required
def status(request, pk=0):
    records=[]
    measge=''
    obj2=None
    detail_ml = {}
    merch_obj = MerchantRecords.objects.filter(user=request.user).first()
    order_obj = Order.objects.filter(customer__custumerrecords__city=merch_obj.city)
    for orders in order_obj:
        obj = orders.orderitem_set.filter(merchants_accepted__merchant__user=request.user)
        records.append(obj)
    if pk:
        obj2=PlaceOrder.objects.filter(order__pk=pk, merchant__merchant__user=request.user).first()
        if not obj2:
            measge="NOT CONFIRMED YET!"
        else:
            measge="ORDER CONFIRMED"
    local_order_obj = Morder.objects.filter(merchant=merch_obj, order=True)
    for loo in local_order_obj:
        item_obj_l = Morderitem.objects.filter(morder__pk=loo.pk)
        detail_ml[loo] = item_obj_l

    # paginator = Paginator(records, 5)  # Show 25 contacts per page.
    # page_number = request.GET.get('page')
    # records = paginator.get_page(page_number)
    return render(request=request,
                  template_name="status.html",
                  context={'detail_ml': detail_ml, 'records': records, 'pk': pk, 'measge': measge, 'main': obj2})
