from django.urls import path
from . import views
app_name="MerchantAPP"


urlpatterns = [
    path('', views.mpage, name="mhome"),
    path('registration/', views.MerchantRegistration, name="Registration"),
    path('login/', views.mlogin, name="Login"),
    path('signup', views.register, name="Signup"),
    path('logout/', views.mlogout, name="Logout"),
    path('timeline/', views.timeline, name="timeline"),
    path('acceptedorder/', views.status, name="order_status"),
    path('acceptedorder/<int:pk>/', views.status, name="order_status"),
]
