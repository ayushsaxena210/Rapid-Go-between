from django.contrib import admin
from .models import MerchantRecords, Category

# Register your models here.
admin.site.register(MerchantRecords)
admin.site.register(Category)
